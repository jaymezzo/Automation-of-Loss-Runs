import tabula

pdf_path = (
    "submission_pdfs/Fernlea Industries_ Inc__Submission_UMB_2024-06-04_012751_392.pdf"
)
tables = tabula.read_pdf(pdf_path, pages="all", multiple_tables=True)

print(tables)
